var p1 = 0;
var p2 = 0;



function preload(){
}


function setup() {
  createCanvas (600,600);
}

function draw() {
  background((p1/2),100,(p2/2));
  fill(255,0,0);
  rect(0,100,p1,25);
  fill(0,0,255);
  rect(0,500,p2,25);
  if (p1>600){
    p1=0;
  }
  if (p2>600){
    p2=0;
  }
  if (p1>0){
    p1=p1-1;
  }
  if (p2>0){
    p2=p2-1;
  }
  fill(255,0,0);
  if (p1>500){
    text ("Almost there!",500,150);
  }
  if (p1>250){
    text ("Keep going!", 250,150);
  }
  if (p1>100){
    text ("You can do it!", 100,150);
  }
  fill(0,0,255);
    if (p2>500){
    text ("Finish it!",500,450);
  }
  if (p2>250){
    text ("Go Faster!", 250,450);
  }
  if (p2>100){
    text ("Beat Player 1!", 100,450);
  }
  fill(0);
  textSize(36);
  textAlign(CENTER);
  text("Wristbreakers!",300,300);
  textSize(14);
  text("Player 1 = Spacebar Player 2 = Enter",300,375)
}

function keyPressed(){
  if (keyCode === 32){
    p1=p1+15;
  }
  if (keyCode === 13){
    p2=p2+15;
  }
}
